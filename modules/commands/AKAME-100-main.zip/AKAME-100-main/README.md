# AKAME BOT

![بوت زوي](https://i.ibb.co/CHY9zmB/464997798.jpg)

<br><br>








AKAME BOT

![بوت زوي](https://i.ibb.co/NFNKL2g/467641208.jpg)

<br><br>










AKAME BOT

![بوت زوي](https://i.ibb.co/FHT2qQZ/465572062.jpg)

<br><br>


